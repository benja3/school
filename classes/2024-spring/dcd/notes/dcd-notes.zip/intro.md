# Intro

## Course Intro 

Class on design of digital hardware to serve a variety of purposes

ASIC: Application Specific IC: Specific Purpose

CPU: General Purpose

CPU: can do anything but at limited speed; ASIC: Can do specific tasks extremely fast

Cost to build: CPU can be much more expensive than necsessary for specific tasks where most of the hardware will not be used

Today, most chips are built to be applcation specific

FPGA: splits difference between custom chip and programmable chip
- chip is not permanently in a certain state, but allows freedom to be redesigned for specific purposes
- allows for remote firmware update 

Lab is mostly independent of class
- theory is taught in lecture

HDL: Hardware Definition Language

VHDL: specific HDL
- old: 40 - 50 years
- created so all chip designs would be in a standard format 

We will be taught a specific design process: mimic this in the lab because it is a good way to do things

VHDL is very complex and capable, do not overwhelm youself with trying to expand beyond course content 

Ligon designed this class, but has not taught it in 10 years

Term computer used loosely for digital circuit that computes

## Syllabus

Course covers doing mathematical operation in hardware, 

timing circuitry:
- synchronization
- all the components need to be controlled so everything flows 

Hardware testing is more intricate than software testing because you won't have debuggers unless you build them in in advance 

event driven: attach hardware to signals such that an operation occurs when a signal is receieved 

can do logic minimization with tabluar methods instead of kmap, these are more easily implemented in computers 

Tests will be tough but grades lenient 


