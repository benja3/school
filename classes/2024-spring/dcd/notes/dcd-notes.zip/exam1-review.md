# Exam 1 Review

## In Class

Exam will be mulitple choice, true false and matching

Multivalue logic: simulation that provides values other than 0 and 1

Z+ and Z- are an attempt to state that the input gate is not driving the output, but is close to a 0 or 1

weak and strong 1's and 0's allow for modelling charge transfer from small to large conductors

a tri state buffer is just a gate with a switch that can put it in Z

When writing VHDL, start with design drawing
- the system drawn will be an entity that has I/O ports
- must determine if ports will be external or internal

to test, must create and instantiate it in a test bench

next, declare architecture based on the entity that contains processes that control the state of the device
- processes contain assignments of signals and ports

a combinational block is a piece that fits inside an architecture

3 types of code in archtectural
- behavioral
- data flow (boolean equation)
- structural
- these are just different styles of programming VHDL

generally not work putting small ocmpooents like couunters in the entity

a test bench is another entity that instantiates the system has code in its architecture to test it

test bench entity typically empty

logcial simulation is 0/1, electrical measures voltages and currents

since electrical simulaiton is much more computlationally intsnse, only do when necessary in certain parts of the system

switch level is between electrical and logical: *** review

rise time vs fall time: consider the time it takes for the signal to change instead of assuming it is instant

strucutral modelin: schematic capture in text

hierarchical: modules and sub modules

IN, OUT, INOUT and BUFFER are directives that assign data flow on ports 

signals connect components, variables are just for local storage and data management
- example: i in the for loop is a variable, and the itnernal bus is a signal
- try to use variables sparingly

concurrent assignment: <= 

flip flop implementation: on the rising edge of the clock, set the output to the input

a register is just mulitple flip flops in parallel
- also have enable, shift right, etc. to add more functionality








## Digital Systems Design

### Traditional

Schematic entry: placing individual gates and primitives

### Bottom Up



